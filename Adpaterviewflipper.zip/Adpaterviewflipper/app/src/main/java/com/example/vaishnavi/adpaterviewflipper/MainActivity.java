package com.example.vaishnavi.adpaterviewflipper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterViewFlipper;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int Images[]={R.drawable.imgone,R.drawable.imgtwo,R.drawable.imgthree,R.drawable.imgfour};
    String Names[]={"Image1","Image2","Image3","Image4"};
    AdapterViewFlipper simpleadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        simpleadapter=(AdapterViewFlipper) findViewById((R.id.androviewflipper));

        // Custom Adapter for setting the data in Views
        CustomAdapter cusadapter = new CustomAdapter(getApplicationContext(),Images,Names);

        // set adapter for AdapterViewFlipper
        simpleadapter.setAdapter(cusadapter);

        // set interval time for flipping between views
       // simpleadapter.setFlipInterval(3000);

        // set auto start for flipping between views
        //simpleadapter.setAutoStart(true);



        simpleadapter.setOnTouchListener(new OnSwipeTouchListener(MainActivity.this) {
            public void onSwipeTop() {
                Toast.makeText(MainActivity.this, "top", Toast.LENGTH_SHORT).show();
                simpleadapter.showPrevious();
            }
            public void onSwipeRight() {
                Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
                simpleadapter.showPrevious();
            }
            public void onSwipeLeft() {
                Toast.makeText(MainActivity.this, "left", Toast.LENGTH_SHORT).show();
                simpleadapter.showNext();
            }
            public void onSwipeBottom() {
                Toast.makeText(MainActivity.this, "bottom", Toast.LENGTH_SHORT).show();
                simpleadapter.showNext();
            }

        });


    }
}
