package com.example.vaishnavi.adpaterviewflipper;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Vaishnavi on 16-01-2018.
 */


    public class CustomAdapter extends BaseAdapter
    {
        Context context;
       int[] Images;
        String[] Names;
       LayoutInflater inflter;

        public CustomAdapter(Context applicationContext, int[] images, String[] names) {
            this.context = applicationContext;
            this.Images = images;
            this.Names = names;
            inflter = (LayoutInflater.from(applicationContext));
        }

        public int getCount()
        {
            return Names.length;
        }

        public Object getItem(int position)
        {
            return null;
        }

        public long getItemId(int position)
        {
            return 0;
        }

        public View getView(int position, View view, ViewGroup parent) {
            view = inflter.inflate(R.layout.list_item, null);
            TextView names = (TextView) view.findViewById(R.id.txtview);
            ImageView images = (ImageView) view.findViewById(R.id.imageView);
            names.setText(Names[position]);
            images.setImageResource(Images[position]);
            return view;
        }

}
